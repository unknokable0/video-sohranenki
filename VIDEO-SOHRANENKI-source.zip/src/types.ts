export type Chapter = {
  id: string;
  time: number;
  title: string;
  kind: "talk" | "watch" | "game" | "moment";
};

export type VideoItem = {
  id: string;
  telegramPostUrl: string;
  title: string;
  publishedAt: string;
  duration: number;
  thumbnail: string;
  streamUrl: string;
  chapters: Chapter[];
};

import { videos as demoVideos } from "../data";
import { VideoItem } from "../types";

const apiUrl = process.env.EXPO_PUBLIC_API_URL;

export async function loadCatalog(): Promise<VideoItem[]> {
  if (!apiUrl) return demoVideos;

  const response = await fetch(`${apiUrl}/videos`);
  if (!response.ok) throw new Error("Не удалось загрузить записи");
  return response.json();
}

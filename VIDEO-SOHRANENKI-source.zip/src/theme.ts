export const colors = {
  background: "#09070D",
  surface: "#14101C",
  surfaceElevated: "#1C1628",
  border: "rgba(255,255,255,0.08)",
  text: "#F8F6FC",
  textSecondary: "#A69DB3",
  accent: "#A66CFF",
  accentStrong: "#8648E8",
  accentSoft: "rgba(166,108,255,0.16)",
  black: "#000000",
};

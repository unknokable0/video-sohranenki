import { VideoItem } from "./types";

const demoStream =
  "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4";

export const videos: VideoItem[] = [
  {
    id: "latest",
    telegramPostUrl: "https://t.me/t2x2_video",
    title: "Свежая запись — смотрим видео и общаемся",
    publishedAt: "Сегодня, 18:40",
    duration: 15060,
    thumbnail:
      "https://images.unsplash.com/photo-1598488035139-bdbb2231ce04?auto=format&fit=crop&w=1200&q=85",
    streamUrl: demoStream,
    chapters: [
      { id: "1", time: 0, title: "Начало записи", kind: "talk" },
      { id: "2", time: 754, title: "Общение с чатом", kind: "talk" },
      { id: "3", time: 1687, title: "Смотрит интересное видео", kind: "watch" },
      { id: "4", time: 2916, title: "Обсуждение", kind: "moment" },
      { id: "5", time: 4922, title: "Игровая часть", kind: "game" }
    ]
  },
  {
    id: "previous",
    telegramPostUrl: "https://t.me/t2x2_video",
    title: "Большой вечерний стрим",
    publishedAt: "Вчера, 20:15",
    duration: 11724,
    thumbnail:
      "https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=1200&q=85",
    streamUrl: demoStream,
    chapters: [
      { id: "1", time: 0, title: "Начало", kind: "talk" },
      { id: "2", time: 945, title: "Новости и общение", kind: "talk" },
      { id: "3", time: 2410, title: "Просмотр видео", kind: "watch" }
    ]
  },
  {
    id: "archive-1",
    telegramPostUrl: "https://t.me/t2x2_video",
    title: "Запись стрима — лучшие моменты",
    publishedAt: "17 сентября",
    duration: 9283,
    thumbnail:
      "https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=1200&q=85",
    streamUrl: demoStream,
    chapters: [
      { id: "1", time: 0, title: "Начало", kind: "talk" },
      { id: "2", time: 1320, title: "Интересный момент", kind: "moment" },
      { id: "3", time: 3860, title: "Смотрит видео", kind: "watch" }
    ]
  }
];

import json
import os
import re
from contextlib import asynccontextmanager
from pathlib import Path

from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response, StreamingResponse
from telethon import TelegramClient
from telethon.sessions import StringSession

load_dotenv()

API_ID = int(os.environ["TG_API_ID"])
API_HASH = os.environ["TG_API_HASH"]
SESSION = os.environ["TG_SESSION"]
CHANNEL = os.getenv("TG_CHANNEL", "t2x2_video")
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "http://127.0.0.1:8000").rstrip("/")
CHAPTERS_PATH = Path(__file__).with_name("chapters.json")

client = TelegramClient(StringSession(SESSION), API_ID, API_HASH)


@asynccontextmanager
async def lifespan(_: FastAPI):
    await client.connect()
    if not await client.is_user_authorized():
        raise RuntimeError("Telegram-сессия недействительна. Запусти authorize.py снова.")
    yield
    await client.disconnect()


app = FastAPI(title="ВИДЕО СОХРАНЕНКИ", lifespan=lifespan)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET"],
    allow_headers=["*"],
)


def chapters_for(message_id: int):
    if not CHAPTERS_PATH.exists():
        return []
    data = json.loads(CHAPTERS_PATH.read_text(encoding="utf-8"))
    return data.get(str(message_id), [])


def get_video_attribute(message):
    if not message.document:
        return None
    return next(
        (attribute for attribute in message.document.attributes if hasattr(attribute, "duration")),
        None,
    )


@app.get("/health")
async def health():
    return {"ok": True, "channel": CHANNEL}


@app.get("/videos")
async def videos(limit: int = 40):
    result = []
    async for message in client.iter_messages(CHANNEL, limit=min(limit, 100)):
        attribute = get_video_attribute(message)
        if not attribute:
            continue

        title = (message.message or "Запись стрима").strip().splitlines()[0]
        if len(title) > 110:
            title = title[:107] + "…"

        result.append(
            {
                "id": str(message.id),
                "telegramPostUrl": f"https://t.me/{CHANNEL}/{message.id}",
                "title": title,
                "publishedAt": message.date.isoformat(),
                "duration": int(attribute.duration),
                "thumbnail": f"{PUBLIC_BASE_URL}/videos/{message.id}/thumbnail",
                "streamUrl": f"{PUBLIC_BASE_URL}/videos/{message.id}/stream",
                "chapters": chapters_for(message.id),
            }
        )
    return result


async def get_video_message(message_id: int):
    message = await client.get_messages(CHANNEL, ids=message_id)
    if not message or not message.document or not get_video_attribute(message):
        raise HTTPException(status_code=404, detail="Видео не найдено")
    return message


@app.get("/videos/{message_id}/thumbnail")
async def thumbnail(message_id: int):
    message = await get_video_message(message_id)
    data = await client.download_media(message, bytes, thumb=-1)
    if not data:
        raise HTTPException(status_code=404, detail="Обложка не найдена")
    return Response(content=data, media_type="image/jpeg", headers={"Cache-Control": "public, max-age=86400"})


@app.get("/videos/{message_id}/stream")
async def stream_video(message_id: int, request: Request, range_header: str | None = Header(default=None, alias="Range")):
    message = await get_video_message(message_id)
    size = int(message.document.size)
    start, end = 0, size - 1

    if range_header:
        match = re.match(r"bytes=(\d*)-(\d*)", range_header)
        if not match:
            raise HTTPException(status_code=416, detail="Некорректный диапазон")
        if match.group(1):
            start = int(match.group(1))
        if match.group(2):
            end = min(int(match.group(2)), size - 1)
        if start > end or start >= size:
            raise HTTPException(status_code=416, detail="Диапазон вне файла")

    remaining = end - start + 1

    async def body():
        sent = 0
        async for chunk in client.iter_download(message.document, offset=start, request_size=512 * 1024):
            if sent + len(chunk) > remaining:
                yield chunk[: remaining - sent]
                return
            yield chunk
            sent += len(chunk)
            if sent >= remaining:
                return

    headers = {
        "Accept-Ranges": "bytes",
        "Content-Length": str(remaining),
        "Content-Range": f"bytes {start}-{end}/{size}",
        "Cache-Control": "private, max-age=3600",
    }
    return StreamingResponse(body(), status_code=206 if range_header else 200, media_type=message.document.mime_type or "video/mp4", headers=headers)

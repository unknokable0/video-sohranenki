import AsyncStorage from "@react-native-async-storage/async-storage";
import { Ionicons } from "@expo/vector-icons";
import { BlurView } from "expo-blur";
import * as Haptics from "expo-haptics";
import { LinearGradient } from "expo-linear-gradient";
import { StatusBar } from "expo-status-bar";
import { useVideoPlayer, VideoView } from "expo-video";
import React, { useEffect, useMemo, useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  ImageBackground,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import { loadCatalog } from "./src/services/catalog";
import { colors } from "./src/theme";
import { VideoItem } from "./src/types";
import { formatDuration } from "./src/format";

type Screen = { name: "home" } | { name: "player"; video: VideoItem };

export default function App() {
  const [screen, setScreen] = useState<Screen>({ name: "home" });
  const [items, setItems] = useState<VideoItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");

  useEffect(() => {
    loadCatalog().then(setItems).finally(() => setLoading(false));
  }, []);

  if (screen.name === "player") {
    return <Player video={screen.video} onBack={() => setScreen({ name: "home" })} />;
  }

  const filtered = items.filter((item) =>
    item.title.toLocaleLowerCase("ru").includes(query.toLocaleLowerCase("ru")),
  );

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <View>
          <Text style={styles.eyebrow}>ЛИЧНЫЙ АРХИВ</Text>
          <Text style={styles.logo}>ВИДЕО{`\n`}СОХРАНЕНКИ</Text>
        </View>
        <Pressable style={styles.avatar}>
          <Ionicons name="person" size={20} color={colors.text} />
        </Pressable>
      </View>

      <View style={styles.search}>
        <Ionicons name="search" size={19} color={colors.textSecondary} />
        <TextInput
          placeholder="Найти запись или момент"
          placeholderTextColor={colors.textSecondary}
          value={query}
          onChangeText={setQuery}
          style={styles.searchInput}
          selectionColor={colors.accent}
        />
        {!!query && (
          <Pressable onPress={() => setQuery("")}>
            <Ionicons name="close-circle" size={19} color={colors.textSecondary} />
          </Pressable>
        )}
      </View>

      {loading ? (
        <ActivityIndicator style={{ flex: 1 }} color={colors.accent} />
      ) : (
        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          ListHeaderComponent={<Text style={styles.sectionTitle}>Все записи</Text>}
          ListEmptyComponent={<Text style={styles.empty}>Ничего не найдено</Text>}
          renderItem={({ item, index }) => (
            <VideoCard
              item={item}
              featured={index === 0 && !query}
              onPress={() => {
                Haptics.selectionAsync();
                setScreen({ name: "player", video: item });
              }}
            />
          )}
        />
      )}

      <BlurView intensity={35} tint="dark" style={styles.tabBar}>
        <Tab icon="home" label="Главная" active />
        <Tab icon="bookmark-outline" label="Сохранённое" />
        <Tab icon="time-outline" label="История" />
      </BlurView>
    </SafeAreaView>
  );
}

function VideoCard({ item, featured, onPress }: { item: VideoItem; featured: boolean; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.card, pressed && { opacity: 0.82 }]}>
      <ImageBackground source={{ uri: item.thumbnail }} style={[styles.cover, featured && styles.coverFeatured]}>
        <LinearGradient colors={["transparent", "rgba(9,7,13,0.9)"]} style={StyleSheet.absoluteFill} />
        {featured && <View style={styles.freshBadge}><Text style={styles.freshText}>СВЕЖАЯ ЗАПИСЬ</Text></View>}
        <View style={styles.duration}><Text style={styles.durationText}>{formatDuration(item.duration)}</Text></View>
        <View style={styles.playCircle}><Ionicons name="play" size={22} color={colors.text} /></View>
      </ImageBackground>
      <View style={styles.cardBody}>
        <Text style={styles.date}>{item.publishedAt}</Text>
        <Text style={styles.cardTitle} numberOfLines={2}>{item.title}</Text>
        <View style={styles.metaRow}>
          <Ionicons name="list" size={15} color={colors.accent} />
          <Text style={styles.meta}>{item.chapters.length} таймкодов</Text>
        </View>
      </View>
    </Pressable>
  );
}

function Player({ video, onBack }: { video: VideoItem; onBack: () => void }) {
  const player = useVideoPlayer(video.streamUrl, (instance) => {
    instance.timeUpdateEventInterval = 1;
  });
  const [position, setPosition] = useState(0);

  useEffect(() => {
    AsyncStorage.getItem(`progress:${video.id}`).then((saved) => {
      if (saved) player.currentTime = Number(saved);
    });
    const subscription = player.addListener("timeUpdate", ({ currentTime }) => {
      setPosition(currentTime);
      AsyncStorage.setItem(`progress:${video.id}`, String(Math.floor(currentTime)));
    });
    return () => subscription.remove();
  }, [player, video.id]);

  const currentChapter = useMemo(() => {
    return [...video.chapters].reverse().find((chapter) => chapter.time <= position);
  }, [position, video.chapters]);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="light" />
      <View style={styles.playerHeader}>
        <Pressable onPress={onBack} style={styles.backButton}>
          <Ionicons name="chevron-back" size={26} color={colors.text} />
        </Pressable>
        <Text style={styles.playerHeaderTitle}>Запись</Text>
        <Pressable style={styles.backButton}>
          <Ionicons name="ellipsis-horizontal" size={24} color={colors.text} />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.playerPage}>
        <VideoView
          player={player}
          style={styles.video}
          nativeControls
          allowsFullscreen
          allowsPictureInPicture
        />
        <View style={styles.nowPlaying}>
          <Text style={styles.playerTitle}>{video.title}</Text>
          <Text style={styles.playerDate}>{video.publishedAt} · {formatDuration(video.duration)}</Text>
        </View>

        <View style={styles.currentChapter}>
          <View style={styles.pulse} />
          <View style={{ flex: 1 }}>
            <Text style={styles.currentLabel}>СЕЙЧАС</Text>
            <Text style={styles.currentText}>{currentChapter?.title ?? "Начало записи"}</Text>
          </View>
          <Text style={styles.currentTime}>{formatDuration(position)}</Text>
        </View>

        <View style={styles.chaptersHeader}>
          <Text style={styles.sectionTitle}>Таймкоды</Text>
          <Text style={styles.chapterCount}>{video.chapters.length} глав</Text>
        </View>
        {video.chapters.map((chapter) => {
          const active = currentChapter?.id === chapter.id;
          return (
            <Pressable
              key={chapter.id}
              onPress={() => {
                player.currentTime = chapter.time;
                player.play();
                Haptics.selectionAsync();
              }}
              style={[styles.chapter, active && styles.chapterActive]}
            >
              <View style={[styles.chapterIcon, active && styles.chapterIconActive]}>
                <Ionicons name={chapter.kind === "game" ? "game-controller" : chapter.kind === "watch" ? "play" : chapter.kind === "moment" ? "sparkles" : "chatbubble"} size={17} color={active ? colors.text : colors.accent} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.chapterTitle, active && { color: colors.text }]}>{chapter.title}</Text>
                <Text style={styles.chapterTime}>{formatDuration(chapter.time)}</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={colors.textSecondary} />
            </Pressable>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

function Tab({ icon, label, active = false }: { icon: keyof typeof Ionicons.glyphMap; label: string; active?: boolean }) {
  return (
    <View style={styles.tab}>
      <Ionicons name={icon} size={22} color={active ? colors.accent : colors.textSecondary} />
      <Text style={[styles.tabText, active && { color: colors.accent }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  header: { paddingHorizontal: 20, paddingTop: Platform.OS === "android" ? 36 : 18, paddingBottom: 18, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  eyebrow: { color: colors.accent, fontSize: 11, fontWeight: "800", letterSpacing: 2.4, marginBottom: 5 },
  logo: { color: colors.text, fontSize: 27, lineHeight: 27, fontWeight: "900", letterSpacing: -1.1 },
  avatar: { width: 43, height: 43, borderRadius: 22, backgroundColor: colors.accentSoft, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: "rgba(166,108,255,0.3)" },
  search: { marginHorizontal: 20, height: 49, borderRadius: 16, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", backgroundColor: colors.surface, borderWidth: 1, borderColor: colors.border, gap: 10 },
  searchInput: { flex: 1, color: colors.text, fontSize: 15 },
  list: { padding: 20, paddingBottom: 110, gap: 15 },
  sectionTitle: { color: colors.text, fontWeight: "800", fontSize: 20, letterSpacing: -0.4, marginBottom: 2 },
  card: { backgroundColor: colors.surface, borderRadius: 22, overflow: "hidden", borderWidth: 1, borderColor: colors.border },
  cover: { height: 170, justifyContent: "center", alignItems: "center" },
  coverFeatured: { height: 205 },
  freshBadge: { position: "absolute", top: 13, left: 13, paddingVertical: 7, paddingHorizontal: 10, borderRadius: 10, backgroundColor: colors.accentStrong },
  freshText: { color: colors.text, fontSize: 10, fontWeight: "900", letterSpacing: 0.8 },
  duration: { position: "absolute", right: 12, bottom: 12, backgroundColor: "rgba(0,0,0,0.78)", paddingVertical: 5, paddingHorizontal: 8, borderRadius: 8 },
  durationText: { color: colors.text, fontWeight: "700", fontSize: 12 },
  playCircle: { width: 53, height: 53, borderRadius: 27, backgroundColor: "rgba(134,72,232,0.92)", justifyContent: "center", alignItems: "center", paddingLeft: 3 },
  cardBody: { padding: 15 },
  date: { color: colors.accent, fontSize: 12, fontWeight: "700", marginBottom: 5 },
  cardTitle: { color: colors.text, fontSize: 17, lineHeight: 22, fontWeight: "700" },
  metaRow: { flexDirection: "row", gap: 6, alignItems: "center", marginTop: 10 },
  meta: { color: colors.textSecondary, fontSize: 12 },
  empty: { color: colors.textSecondary, textAlign: "center", paddingTop: 60 },
  tabBar: { position: "absolute", bottom: 0, left: 0, right: 0, height: 82, borderTopWidth: 1, borderColor: colors.border, flexDirection: "row", paddingTop: 11 },
  tab: { flex: 1, alignItems: "center", gap: 4 },
  tabText: { color: colors.textSecondary, fontSize: 10, fontWeight: "600" },
  playerHeader: { height: 64, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  playerHeaderTitle: { color: colors.text, fontWeight: "700", fontSize: 16 },
  backButton: { width: 44, height: 44, justifyContent: "center", alignItems: "center" },
  playerPage: { paddingBottom: 36 },
  video: { width: "100%", aspectRatio: 16 / 9, backgroundColor: colors.black },
  nowPlaying: { padding: 20 },
  playerTitle: { color: colors.text, fontSize: 22, lineHeight: 28, fontWeight: "800", letterSpacing: -0.5 },
  playerDate: { color: colors.textSecondary, fontSize: 13, marginTop: 8 },
  currentChapter: { marginHorizontal: 20, backgroundColor: colors.accentSoft, borderColor: "rgba(166,108,255,0.28)", borderWidth: 1, borderRadius: 17, padding: 14, flexDirection: "row", alignItems: "center", gap: 11 },
  pulse: { width: 9, height: 9, borderRadius: 5, backgroundColor: colors.accent },
  currentLabel: { color: colors.accent, fontSize: 9, fontWeight: "900", letterSpacing: 1.4 },
  currentText: { color: colors.text, fontSize: 14, fontWeight: "700", marginTop: 3 },
  currentTime: { color: colors.textSecondary, fontSize: 12, fontVariant: ["tabular-nums"] },
  chaptersHeader: { marginTop: 28, paddingHorizontal: 20, marginBottom: 10, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  chapterCount: { color: colors.textSecondary, fontSize: 12 },
  chapter: { marginHorizontal: 20, paddingVertical: 12, paddingHorizontal: 12, borderRadius: 15, flexDirection: "row", alignItems: "center", gap: 12 },
  chapterActive: { backgroundColor: colors.surfaceElevated },
  chapterIcon: { width: 38, height: 38, borderRadius: 12, backgroundColor: colors.accentSoft, alignItems: "center", justifyContent: "center" },
  chapterIconActive: { backgroundColor: colors.accentStrong },
  chapterTitle: { color: "#DCD5E6", fontWeight: "600", fontSize: 14 },
  chapterTime: { color: colors.textSecondary, fontSize: 11, marginTop: 3, fontVariant: ["tabular-nums"] },
});
